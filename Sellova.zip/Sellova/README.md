# Sellova Website

Sellova is a simple landing site offering 3 services:
- Marketing
- Web Design
- Graphics

### To use:
Open `index.html` in your browser.

### To deploy:
Upload all files to GitHub and activate GitHub Pages from the repository settings.
